# Consigne

En guise d’exercice, je vous propose de continuer l’interface que nous avons commencée en rajoutant les boutons suivants.

## Niveau 1

+ `Répéter` : *checkbox* qui fera répéter la vidéo lorsqu'elle se termine si elle est cochée ;
+ `Avancer/Reculer de xx secondes` : un *input* de votre choix pour sélectionner une valeur et deux boutons pour avancer ou reculer.

## Niveau 2

Pour les plus forts :

+ Une barre de progression pour afficher où la vidéo est rendue dans sa lecture ;
+ Un *input* de type *range* pour :
    + afficher où la vidéo est rendue ;
    + sélectionner un endroit où aller.

## Niveau 3

Prouvez que vous être le maître des technos Web, rajoutez une belle couche de CSS par dessus tout cela !

->

Voila, ça fera de quoi vous occuper :pirate: !

**BON COURAGE** <-

# Solution

Voici un exemple simple de solution « Niveau 1 » :

->

!(https://jsfiddle.net/tmjosu22/16/)

<-

Et voila une deuxième démo mettant plus l'accent sur le style que sur les fonctions.

->

!(https://jsfiddle.net/tmjosu22/20/)

<-