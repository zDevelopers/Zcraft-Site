Démarrons donc le développement de notre application. Afin de vous fournir un exemple concret de ce qui est faisable en ASP.NET MVC, nous vous proposons de créer un blog complet.

Ce blog sera notre fil rouge, à la fin de ce tutoriel, il devrait être complet avec ajout et suppression des articles, des commentaires, affichage en temps réel...

Pour faire cela, créez une application avec le template MVC. Choisissez l'authentification "Comptes d'utilisateur individuels".