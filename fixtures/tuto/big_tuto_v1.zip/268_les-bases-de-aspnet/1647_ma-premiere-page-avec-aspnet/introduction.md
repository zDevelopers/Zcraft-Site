La tradition, chez les développeurs, quand on touche à une nouvelle technologie, c'est de dire bonjour au monde grâce à cette technologie.
Dans ce chapitre, nous allons enfin toucher à l'ASP.NET. Nous ne commencerons pas en force, nous verrons comment créer une petite application Web avec l'organisation Modèle-Vue-Contrôleur.

Alors en avant pour notre premier **Hello Word** !