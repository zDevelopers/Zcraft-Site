Ce chapitre est terminé, deux notions importantes et assez simples à assimiler.
Les filtres permettent de spécifier les conditions à respecter au début ou à la fin d'un contrôleur ou d'une action.  
Les routes, quand à elles, décrivent les demandes entrantes de navigateur via l'url pour des actions de contrôleur particulières.

Nous avons beaucoup parlé de **contrôleur** dans ce chapitre, il serait temps d'en savoir un peu plus sur eux. Ca tombe bien car nous en parlons au prochain chapitre.