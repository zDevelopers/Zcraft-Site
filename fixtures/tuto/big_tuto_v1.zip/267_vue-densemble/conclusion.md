Pour conclure cette partie, rien de mieux qu'une petite vidéo qui vous propose une visite guidée dans les méandres de Visual Studio et ASP.NET.

!()