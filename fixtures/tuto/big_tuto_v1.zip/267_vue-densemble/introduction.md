Vous avez décidé de vous lancer dans le développement Web avec ASP.NET ? Félicitations, c'est un très bon choix ! Pourquoi ? Vous aurez l'occasion de le découvrir au travers ce tutoriel et notamment dans ce premier chapitre. 

**ASP.NET** est un ensemble d'outils à disposition du développeur (vous). Voyez cela comme une grosse boîte contenant divers outils prêts à utilisation pour permettre de développer simplement et sans réinventer la roue une application Web.

Dans ce tutoriel, nous apprendrons à utiliser certains outils de cette boîte, pas tous car il y en a vraiment, *vraiment* beaucoup. Ce chapitre va introduire ASP.NET, de la définition de son architecture à l'installation des composants pour commencer à programmer.

Allez, c'est parti !