Une fois le programme d'installation téléchargé, il ne reste plus qu’à le lancer et l’installation démarre. Installez Visual Studio Express pour le Web en laissant toutes les options par défauts.

Un fois l'installation terminée, lancez Visual Studio Express pour le Web, celui-ci va effectuer une première configuration.

->![Bienvenue dans Visual Studio pour le Web](/media/galleries/304/74ac43f8-e8e2-4d27-9573-6994c27d7f96.png.960x960_q85.jpg)<-

Visual Studio Express pour le Web finalise nos paramètres, nous sommes prêt à commencer.

Il vous est proposé de vous connecter. Même si cela n'a rien de nécessaire, nous vous conseillons de le faire. Cela vous permettra de récupérer vos paramètres d'utilisation lorsque vous changerez de PC par exemple.
Cliquez sur **Se connecter** pour démarrer la configuration utilisateur.

->![Etape du compte Microsoft](/media/galleries/304/63951e80-f0a4-4a59-ac84-fd06b0596243.png.960x960_q85.jpg)<-

Visual Studio nous demande notre adresse de compte Microsoft.

[[question]]
| Je n'ai pas de compte Microsoft moi !

Si vous n'avez pas d'adresse de messagerie, ce n'est pas un problème : le programme de mise en route vous permet d'en créer une.  
Pour cela, cliquez sur **Inscription** pour obtenir une nouvelle adresse de messagerie. Vous devez alors choisir votre nouvelle adresse et entrer quelques informations utiles. Une fois que vous aurez terminé, vous pourrez passer à l'étape suivante.

->![Informations supplémentaires](/media/galleries/304/4996f8f0-7615-44b7-a59f-be91132b3028.png.960x960_q85.jpg)<-

Sur cette page, l'installateur vous propose de rentrer votre nom et une case à cocher. Si vous autorisez Microsoft à récupérer des informations sur votre ordinateur et des statistiques pour ses bases de données, laissez comme tel. Dans le cas contraire, décochez la case. Cliquez ensuite sur le bouton **Continuer**. En cliquant sur ce bouton, vous acceptez les conditions d'utilisation du logiciel.