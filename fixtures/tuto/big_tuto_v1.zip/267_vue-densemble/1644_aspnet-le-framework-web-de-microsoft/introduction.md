Lorsque vous visitez un site Web, vous avez en général la possibilité de lire ou d'écrire du contenu, de créer un compte, d'envoyer des messages et d'administrer votre compte. Tout cela sans que vous ayez à vous soucier de comment ça fonctionne derrière.

Jusque là, vous avez appris le HTML et le CSS qui permettent respectivement de décrire et de mettre en forme l'interface visiteur de votre site. Alors comment fonctionne ASP.NET dans tout cela ? Quel rôle joue-t-il ?

Ce premier chapitre est là pour répondre à ces questions.