C'est ainsi que se termine ce premier chapitre. Retenez donc que ASP.NET regroupe plusieurs technologies qui permettent de dynamiser les sites Web. J'espère que nous vous avons donné envie de créer votre prochaine application Web avec ASP.NET.

Dans le prochain chapitre, nous découvrirons les outils à installer pour commencer à utiliser ASP.NET.