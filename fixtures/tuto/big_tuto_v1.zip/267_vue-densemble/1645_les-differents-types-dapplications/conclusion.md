Nous avons vu les différents modèles qu'offrait le Framework Web ASP.NET à travers ce chapitre. Il offre différents styles de programmation, ce qui montre que ASP.NET est vaste. Dans ce tutoriel, nous utiliserons le modèle MVC (Modèle-Vue-Contrôleur) car il permet de conserver une bonne organisation dans le code.

Cela tombe bien car nous commençons dès le prochain chapitre !