Bien, vous en avez assez de devoir supprimer votre base de données à chaque fois? J'ai la solution pour vous : les migrations.

Ce chapitre vous expliquera comment les créer, les modifier et les appliquer.

